// var cardOne ="queen";
// var cardTwo ="queen";
// var cardThree ="king";
// var cardFour ="king";

// console.log("User flipped " + cardOne);

cards =["queen","queen","king","king"];
const cardsInPlay =[];


function createBoard()
{
 function flipCard()
 {
 	function checkForMatch()

 	{
 		  function createBoard()
  {
  	var newListItem = document.createElement('img');
  	for (var i = 0; i < cards.length; i++) {
    cardElement.setAttribute(src="images/back.png");

    cardElement.setAttribute('attributeName', 'attributeValue');

    cardElement.setAttribute('data-id');

    cardElement.appendChild(game-board)
}
 	var cardId;

 	var cardOne = cards[0];
	cardsInPlay.push(cards[cardId]);
	console.log("User flipped " + cardOne);

	var cardTwo = cards[2];
	cardsInPlay.push(cards[cardId]);
	console.log("User flipped " + cardTwo);

 	var myArray = [
{
	rank:"queen",
	suit:"hearts",
	cardImage:"images/queen-of-hearts.png",
	color: "red",
	flower: "rose",
	petals: 20
},
{
	rank:"queen",
	suit:"diamonds",
	cardImage:"images/queen-of-diamonds.png",
	color: 'blue',
	flower: 'violet',
	petals: 6
}
];
 	 cardElement.setAttribute(cards[cardImage])
 	
if (cardsInPlay[0] === cardsInPlay[1]) {
  console.log("You found a match!");
} else {
  console.log("Sorry, try again.");
}
	console.log("User flipped "+cards[cardId]);

	console.log("User flipped "+cards[cardId]);

	console.log("User flipped "+cards[cardId]);
	console.log(cards[cardId].cardImage)
}
checkForMatch();
}

 flipCard(0);
 flipCard(2);


this.getAttribute('attribute-we-want-to-get-goes-here');
	cardElement.addEventListener('click')
}
	createBoard();
}



